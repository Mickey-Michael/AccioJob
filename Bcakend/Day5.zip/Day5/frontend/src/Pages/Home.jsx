import { useEffect } from "react"

const Home = () => {

  useEffect(() => {
    fetch(import.meta.env.VITE_BACKEND_URL + "/todos")
    .then((res) => {
      return res.json()
    })
    .then((data) => {
      console.log(data)
    })

  },[])

  return (
    <div>home</div>
  )
}

export default Home
